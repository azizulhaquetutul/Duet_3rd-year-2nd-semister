package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.bumptech.glide.Glide
class Onboarding-1 : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_onboarding-_1)
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/zMIpo7xant/53x9kwqk_expires_30_days.png").into(findViewById(R.id.rq3a9vefpjsn))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/zMIpo7xant/8608u7t3_expires_30_days.png").into(findViewById(R.id.rxh6klyawnkl))
		val button1: View = findViewById(R.id.r6ms7rhoqquc)
		button1.setOnClickListener {
			println("Pressed")
		}
	}
}