package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class OtpVerificationActivity extends AppCompatActivity {

    private EditText otpDigit1, otpDigit2, otpDigit3, otpDigit4;
    private LinearLayout verifyButton;
    private ImageView backIcon;

    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);

        email = getIntent().getStringExtra("email");

        otpDigit1 = findViewById(R.id.otp_digit1);
        otpDigit2 = findViewById(R.id.otp_digit2);
        otpDigit3 = findViewById(R.id.otp_digit3);
        otpDigit4 = findViewById(R.id.otp_digit4);
        verifyButton = findViewById(R.id.rkz05vo2czek);
        backIcon = findViewById(R.id.back_arrow);

        backIcon.setOnClickListener(v -> finish());

        verifyButton.setOnClickListener(v -> verifyOtp());
    }

    private void verifyOtp() {
        String enteredOtp = otpDigit1.getText().toString() + otpDigit2.getText().toString() +
                otpDigit3.getText().toString() + otpDigit4.getText().toString();

        if (enteredOtp.length() != 4) {
            Toast.makeText(this, "Enter complete OTP", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");

        usersRef.orderByChild("email").equalTo(email)
                .get().addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult().exists()) {
                        for (DataSnapshot snapshot : task.getResult().getChildren()) {
                            String dbOtp = snapshot.child("otp").getValue(String.class);
                            if (dbOtp != null && dbOtp.equals(enteredOtp)) {
                                snapshot.getRef().child("otp").removeValue(); // OTP মুছে ফেলুন
                                Toast.makeText(this, "OTP Verified", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(this, NewPasswordActivity.class);
                                intent.putExtra("email", email);
                                startActivity(intent);
                                finish();
                                return;
                            }
                        }
                        Toast.makeText(this, "Incorrect OTP", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
