package com.example.healthcarebd;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class activity_home_page extends AppCompatActivity {

    private EditText searchText;
    private ImageView micIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // একবার SharedPreferences declare ও use করা হচ্ছে
        SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userType = preferences.getString("userType", "");

        // Service Cards লিস্টেনার
        findViewById(R.id.rcq1d4rpdjvg).setOnClickListener(v -> openAppointmentBooking());
        findViewById(R.id.rxenlyqf2mg).setOnClickListener(v -> showToast("Total Household Clicked"));
        findViewById(R.id.rola0dc7r04s).setOnClickListener(v -> showToast("Mothercare Clicked"));
        findViewById(R.id.rquu6k4kfum).setOnClickListener(v -> showToast("Medicine Clicked"));
        findViewById(R.id.r8vnxw5yxfbq).setOnClickListener(v -> showToast("Child List Clicked"));

        // ডাক্তারের জন্য patient profile এ যাওয়ার বাটন
        findViewById(R.id.rj3dk4s1h8sr).setOnClickListener(v -> {
            if ("Doctor".equalsIgnoreCase(userType)) {
                Intent intent = new Intent(activity_home_page.this, activity_patient_profile.class);
                startActivity(intent);
            } else {
                Toast.makeText(activity_home_page.this, "Access Denied: Only doctors can view patient list", Toast.LENGTH_SHORT).show();
            }
        });

        // Doctor Category Cards
        findViewById(R.id.rbmbx4nw9uzw).setOnClickListener(v -> goToDoctorList("Pathologist"));
        findViewById(R.id.rs7xa3mb5bms).setOnClickListener(v -> goToDoctorList("Female Gynecologist"));
        findViewById(R.id.rrn8urbfmi4).setOnClickListener(v -> goToDoctorList("Child Doctor"));
        findViewById(R.id.rwd3q4gx2w5).setOnClickListener(v -> goToDoctorList("Dermatologist"));
        findViewById(R.id.rwd3q4gx2w6).setOnClickListener(v -> goToDoctorList("Nutritionist"));
        findViewById(R.id.rwd3q4gx2w7).setOnClickListener(v -> goToDoctorList("Orthopedic"));
        findViewById(R.id.rwd3q4gx2w8).setOnClickListener(v -> goToDoctorList("Neurologist"));

        // Top Specialists - Clickable Doctor Cards
        findViewById(R.id.orthopedist).setOnClickListener(v -> openDoctorBooking("Orthopedist"));
        findViewById(R.id.ent).setOnClickListener(v -> openDoctorBooking("ENT"));
        findViewById(R.id.cardiologist).setOnClickListener(v -> openDoctorBooking("Cardiologist"));
        findViewById(R.id.neurologist).setOnClickListener(v -> openDoctorBooking("Neurologist"));
        findViewById(R.id.dermatologist).setOnClickListener(v -> openDoctorBooking("Dermatologist"));
        findViewById(R.id.cardiologist1).setOnClickListener(v -> openDoctorBooking("Cardiologist"));
        findViewById(R.id.cardblinken).setOnClickListener(v -> openDoctorBooking("Dermatologist"));
        findViewById(R.id.cardlindabrain).setOnClickListener(v -> openDoctorBooking("Gynecologist"));

        // Bottom Navigation
        findViewById(R.id.rzfditkz8wsj).setOnClickListener(v -> showToast("You are on Home"));
        findViewById(R.id.r2m1b5oo1qfo).setOnClickListener(v -> showToast("Consult Page Coming Soon"));
        findViewById(R.id.rrxiwn0hmwp).setOnClickListener(v -> showToast("Scan Page Coming Soon"));
        findViewById(R.id.rtsebyjnvndh).setOnClickListener(v -> showToast("Bookings Page Coming Soon"));
        findViewById(R.id.r8panjt8bize).setOnClickListener(v -> {
            Intent intent = new Intent(activity_home_page.this, DoctorProfileActivity.class);
            intent.putExtra("doctorName", "Dr. Ahsan Ullah");
            intent.putExtra("doctorSpecialist", "Medicine Specialist");
            intent.putExtra("doctorTime", "10:00 AM - 3:00 PM");
            intent.putExtra("doctorImage", "https://example.com/doctor_image.jpg");
            startActivity(intent);
        });

        // Header Icons
        findViewById(R.id.rkabnwdeudul).setOnClickListener(v -> showToast("Menu clicked"));
        findViewById(R.id.rxvden3zix1).setOnClickListener(v -> showToast("Language switch clicked (EN)"));
        findViewById(R.id.rwa77lexfg17).setOnClickListener(v -> showToast("Notifications clicked"));

        // Search & Voice Input Setup
        searchText = findViewById(R.id.ru2bhg530w5);
        micIcon = findViewById(R.id.rmkw3jqzp8i);

        searchText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                performSearch(s.toString().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        micIcon.setOnClickListener(v -> {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say something...");
            startActivityForResult(intent, 100);
        });

        // Popup Menu Setup
        ImageView menuIcon = findViewById(R.id.rkabnwdeudul);
        menuIcon.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(activity_home_page.this, menuIcon);
            popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

            popup.setOnMenuItemClickListener(item -> {
                int id = item.getItemId();
                if (id == R.id.menu_household) {
                    showToast("Total Household Clicked");
                    return true;
                } else if (id == R.id.menu_mothercare) {
                    showToast("Mothercare Clicked");
                    return true;
                } else if (id == R.id.menu_medicine) {
                    showToast("Medicine Clicked");
                    return true;
                } else if (id == R.id.menu_child) {
                    showToast("Child List Clicked");
                    return true;
                } else if (id == R.id.menu_vaccine) {
                    showToast("Vaccine Clicked");
                    return true;
                } else if (id == R.id.menu_signout) {
                    FirebaseAuth.getInstance().signOut();
                    showToast("Signed out successfully");
                    startActivity(new Intent(this, activity_user_selection.class));
                    finish();
                    return true;
                }
                return false;
            });

            popup.show();
        });
    }

    private void openAppointmentBooking() {
        startActivity(new Intent(this, activity_appointment_booking.class));
    }

    private void goToDoctorList(String doctorType) {
        Intent intent = new Intent(this, activity_appointment_booking.class);
        intent.putExtra("doctorType", doctorType);
        startActivity(intent);
    }

    private void openDoctorBooking(String doctorType) {
        Intent intent = new Intent(this, activity_appointment_booking.class);
        intent.putExtra("doctorType", doctorType);
        startActivity(intent);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void performSearch(String query) {
        if (query.isEmpty()) {
            showToast("Please type something to search");
        } else {
            showToast("Searching for: " + query);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                String voiceText = result.get(0);
                searchText.setText(voiceText);
                performSearch(voiceText);
            }
        }
    }
}
