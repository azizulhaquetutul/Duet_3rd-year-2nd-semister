package com.example.healthcarebd;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {

    private Context context;
    private ArrayList<User> doctorList;

    public DoctorAdapter(Context context, ArrayList<User> doctorList) {
        this.context = context;
        this.doctorList = doctorList;
    }

    @NonNull
    @Override
    public DoctorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.doctor_item, parent, false);
        return new DoctorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DoctorViewHolder holder, int position) {
        User doctor = doctorList.get(position);

        holder.tvName.setText(doctor.name);
        holder.tvSpecialist.setText(doctor.specialist);
        holder.tvTime.setText(doctor.time);

        Glide.with(context)
                .load(doctor.profileImage)
                .placeholder(R.drawable.ic_profile2)
                .error(R.drawable.ic_profile)
                .into(holder.imgProfile);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DoctorProfileActivity.class);
            intent.putExtra("doctorName", doctor.name);
            intent.putExtra("doctorSpecialist", doctor.specialist);
            intent.putExtra("doctorTime", doctor.time);
            intent.putExtra("doctorImage", doctor.profileImage);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return doctorList.size();
    }

    public static class DoctorViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvSpecialist, tvTime;
        ImageView imgProfile;

        public DoctorViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvDoctorName);
            tvSpecialist = itemView.findViewById(R.id.tvDoctorSpecialist);
            tvTime = itemView.findViewById(R.id.tvDoctorTime);
            imgProfile = itemView.findViewById(R.id.imgDoctorProfile);
        }
    }
}
