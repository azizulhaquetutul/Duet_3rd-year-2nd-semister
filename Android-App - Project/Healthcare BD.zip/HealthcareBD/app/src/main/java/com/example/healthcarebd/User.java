package com.example.healthcarebd;

public class User {
    public String id;
    public String name;
    public String email;
    public String password;
    public String userType;       // Admin / Doctor / Patient
    public String specialist;     // Doctor only
    public String time;           // Doctor availability
    public String status;         // Doctor status
    public String profileImage;   // Profile image URL
    public String otp;

    public User() {
        // Required by Firebase
    }

    public User(String name, String email, String password, String userType, String profileImage) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.userType = userType;
        this.profileImage = profileImage;
        this.otp = "";
    }

    public User(String name, String email, String password, String userType, String profileImage,
                String specialist, String time, String status) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.userType = userType;
        this.profileImage = profileImage;
        this.specialist = specialist;
        this.time = time;
        this.status = status;
        this.otp = "";
    }
}
