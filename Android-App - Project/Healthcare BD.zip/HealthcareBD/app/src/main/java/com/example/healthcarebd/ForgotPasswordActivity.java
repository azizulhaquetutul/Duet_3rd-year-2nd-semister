package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText forgotEmailInput;
    private LinearLayout sendButton;
    private ImageView backIcon;

    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        forgotEmailInput = findViewById(R.id.refzx1b5zxdp);
        sendButton = findViewById(R.id.rkz05vo2czek);
        backIcon = findViewById(R.id.r9lfdvfelny6);

        userRef = FirebaseDatabase.getInstance().getReference("Users");

        backIcon.setOnClickListener(v -> finish());

        sendButton.setOnClickListener(v -> {
            String email = forgotEmailInput.getText().toString().trim();

            if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(ForgotPasswordActivity.this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
            } else {
                generateAndSendOtp(email);
            }
        });
    }

    private void generateAndSendOtp(String email) {
        userRef.orderByChild("email").equalTo(email).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                String otp = String.valueOf(new Random().nextInt(9000) + 1000);

                for (DataSnapshot snapshot : task.getResult().getChildren()) {
                    snapshot.getRef().child("otp").setValue(otp);
                    String userId = snapshot.getKey();

                    Toast.makeText(this, "OTP Sent: " + otp, Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(ForgotPasswordActivity.this, OtpVerificationActivity.class);
                    intent.putExtra("userId", userId);
                    intent.putExtra("email", email);  // Email পাঠানো গুরুত্বপূর্ণ
                    startActivity(intent);
                    finish();
                    break;
                }
            } else {
                Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
