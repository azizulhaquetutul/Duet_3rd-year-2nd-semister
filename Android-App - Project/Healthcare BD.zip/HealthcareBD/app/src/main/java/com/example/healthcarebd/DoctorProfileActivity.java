package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DoctorProfileActivity extends AppCompatActivity {

    ImageView btnBack, imgDoctorProfile;
    TextView tvDoctorName, tvDoctorSpecialist, tvDoctorTime;
    Button btnBookAppointment; // <-- Added

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        // Initialize views
        btnBack = findViewById(R.id.btnBack);
        imgDoctorProfile = findViewById(R.id.imgDoctorProfile);
        tvDoctorName = findViewById(R.id.tvDoctorName);
        tvDoctorSpecialist = findViewById(R.id.tvDoctorSpecialist);
        tvDoctorTime = findViewById(R.id.tvDoctorTime);
        btnBookAppointment = findViewById(R.id.btnBookAppointment); // <-- Initialize

        // Get data from intent
        Intent intent = getIntent();
        String doctorName = intent.getStringExtra("doctorName");
        String doctorSpecialist = intent.getStringExtra("doctorSpecialist");
        String doctorTime = intent.getStringExtra("doctorTime");
        String doctorImageUrl = intent.getStringExtra("doctorImage");

        // Set data to views
        tvDoctorName.setText(doctorName != null ? doctorName : "Dr. Name");
        tvDoctorSpecialist.setText(doctorSpecialist != null ? doctorSpecialist : "Specialist");
        tvDoctorTime.setText(doctorTime != null ? doctorTime : "Available Time");

        if (doctorImageUrl != null && !doctorImageUrl.isEmpty()) {
            Glide.with(this).load(doctorImageUrl).into(imgDoctorProfile);
        }

        // Back button
        btnBack.setOnClickListener(view -> finish());

        // Book Appointment button
        btnBookAppointment.setOnClickListener(view -> {
            Intent bookIntent = new Intent(this,activity_payment.class);
            bookIntent.putExtra("doctorName", doctorName);
            bookIntent.putExtra("doctorSpecialist", doctorSpecialist);
            bookIntent.putExtra("doctorImage", doctorImageUrl);
            bookIntent.putExtra("doctorTime", doctorTime);
            startActivity(bookIntent);
        });

    }
}
