package com.example.healthcarebd;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class activity_admin_add_doctor extends AppCompatActivity {

    EditText doctorNameInput, doctorEmailInput, doctorPasswordInput;
    EditText doctorSpecializationInput, doctorTimeInput;
    ImageView imageURL, backButton;
    LinearLayout addDoctorButtonLayout;

    FirebaseAuth mAuth;
    DatabaseReference dbRef;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_doctor);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("Users");

        // Initialize views
        backButton = findViewById(R.id.backButton);
        imageURL = findViewById(R.id.imageURL);
        doctorNameInput = findViewById(R.id.doctorNameInput);
        doctorEmailInput = findViewById(R.id.doctorEmailInput);
        doctorPasswordInput = findViewById(R.id.doctorPasswordInput);
        doctorSpecializationInput = findViewById(R.id.doctorSpecializationInput);
        doctorTimeInput = findViewById(R.id.doctorTimeInput);
        addDoctorButtonLayout = findViewById(R.id.addDoctorButtonLayout);

        // Progress Dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Adding doctor...");
        progressDialog.setCancelable(false);

        // Back button click
        backButton.setOnClickListener(v -> finish());

        // Upload image click listener (future use)
        imageURL.setOnClickListener(v -> {
            Toast.makeText(this, "Image upload functionality coming soon!", Toast.LENGTH_SHORT).show();
        });

        // Add Doctor button click
        addDoctorButtonLayout.setOnClickListener(v -> addDoctor());
    }

    private void addDoctor() {
        String name = doctorNameInput.getText().toString().trim();
        String email = doctorEmailInput.getText().toString().trim();
        String password = doctorPasswordInput.getText().toString().trim();
        String specialization = doctorSpecializationInput.getText().toString().trim();
        String time = doctorTimeInput.getText().toString().trim();
        String imageUrl = ""; // Optional: later you can set uploaded image URL

        // Input validation
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();

        // Create Firebase Auth user
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser newUser = task.getResult().getUser();

                        // Optional: Set name in Firebase Auth profile
                        UserProfileChangeRequest update = new UserProfileChangeRequest.Builder()
                                .setDisplayName(name)
                                .build();
                        newUser.updateProfile(update);

                        // Store doctor data in Firebase Realtime DB
                        String doctorId = newUser.getUid();
                        HashMap<String, Object> doctorData = new HashMap<>();
                        doctorData.put("id", doctorId);
                        doctorData.put("name", name);
                        doctorData.put("email", email);
                        doctorData.put("specialist", specialization);
                        doctorData.put("time", time);
                        doctorData.put("profileImage", imageUrl); // if uploaded
                        doctorData.put("userType", "Doctor");

                        dbRef.child(doctorId).setValue(doctorData)
                                .addOnCompleteListener(dbTask -> {
                                    progressDialog.dismiss();
                                    if (dbTask.isSuccessful()) {
                                        Toast.makeText(this, "Doctor added successfully!", Toast.LENGTH_SHORT).show();
                                        finish(); // Go back to previous screen
                                    } else {
                                        Toast.makeText(this, "Failed to save doctor info!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}
