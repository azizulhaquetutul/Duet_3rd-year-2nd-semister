package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class activity_user_selection extends AppCompatActivity {

    private String selectedUserType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selection);

        ImageView backIcon = findViewById(R.id.r6max8rhs4wo);
        ImageView dropdownIcon = findViewById(R.id.r4ofilc9lkg8);
        TextView selectedUserText = findViewById(R.id.rxozhjvc87pp);
        LinearLayout continueButton = findViewById(R.id.rolmvaui607k);

        // à¦†à¦—à§‡à¦° à¦ªà§‡à¦œ à¦¥à§‡à¦•à§‡ userType à¦¨à¦¾à¦“
        selectedUserType = getIntent().getStringExtra("userType");
        if (selectedUserType == null) selectedUserType = "";

        // UI à¦¤à§‡ à¦¦à§‡à¦–à¦¾à¦“
        if (!selectedUserType.isEmpty()) {
            selectedUserText.setText(selectedUserType);
        }

        backIcon.setOnClickListener(v -> {
            Intent intent = new Intent(activity_user_selection.this, OnboardingActivity.class);
            intent.putExtra("step", 3);
            startActivity(intent);
            finish();
        });

        dropdownIcon.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(this, dropdownIcon);
            popupMenu.getMenu().add("Patient");
            popupMenu.getMenu().add("Doctor");
            popupMenu.getMenu().add("Admin");

            popupMenu.setOnMenuItemClickListener(item -> {
                selectedUserText.setText(item.getTitle());
                selectedUserType = item.getTitle().toString();
                return true;
            });

            popupMenu.show();
        });

        continueButton.setOnClickListener(v -> {
            String selectedUser = selectedUserText.getText().toString().trim();
            if (selectedUser.isEmpty() || selectedUser.equals("Select user")) {
                Toast.makeText(this, "Please select a user type", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(activity_user_selection.this, activity_sign_in.class);
                intent.putExtra("userType", selectedUserType);
                startActivity(intent);
                finish();
            }
        });
    }
}
