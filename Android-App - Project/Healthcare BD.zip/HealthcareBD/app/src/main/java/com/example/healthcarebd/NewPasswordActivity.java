package com.example.healthcarebd;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NewPasswordActivity extends AppCompatActivity {

    private EditText newPasswordInput, confirmPasswordInput;
    private LinearLayout continueButton;
    private ImageView backIcon;

    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);

        newPasswordInput = findViewById(R.id.rb36q4s6rlst);
        confirmPasswordInput = findViewById(R.id.r7bmy2vyffcx);
        continueButton = findViewById(R.id.rged1p4qbbl);
        backIcon = findViewById(R.id.r91kdx8lcifg);

        email = getIntent().getStringExtra("email");

        backIcon.setOnClickListener(v -> finish());

        continueButton.setOnClickListener(v -> {
            String newPassword = newPasswordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            if (newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(NewPasswordActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (!newPassword.equals(confirmPassword)) {
                Toast.makeText(NewPasswordActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                if(email != null && !email.isEmpty()){
                    updatePasswordInFirebase(email, newPassword);
                } else {
                    Toast.makeText(NewPasswordActivity.this, "Invalid user email", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void updatePasswordInFirebase(String email, String newPassword) {
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users");

        userRef.orderByChild("email").equalTo(email).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                for (DataSnapshot snapshot : task.getResult().getChildren()) {
                    snapshot.getRef().child("password").setValue(newPassword).addOnCompleteListener(task1 -> {
                        if (task1.isSuccessful()) {
                            Toast.makeText(NewPasswordActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(NewPasswordActivity.this, "Failed to update password", Toast.LENGTH_SHORT).show();
                        }
                    });
                    break; // একবার পেয়ে গেলে আর লুপ না চালানো
                }
            } else {
                Toast.makeText(NewPasswordActivity.this, "User not found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
