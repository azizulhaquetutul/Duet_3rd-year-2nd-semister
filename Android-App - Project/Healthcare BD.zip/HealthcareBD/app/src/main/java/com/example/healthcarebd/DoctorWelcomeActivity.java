package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class DoctorWelcomeActivity extends AppCompatActivity {

    LinearLayout viewProfileButtonLayout, goHomeButtonLayout, logoutButtonLayout;
    ImageView backIconDoctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_welcome);

        backIconDoctor = findViewById(R.id.backIconDoctor);
        viewProfileButtonLayout = findViewById(R.id.viewProfileButtonLayout);
        goHomeButtonLayout = findViewById(R.id.goHomeButtonLayout);
        logoutButtonLayout = findViewById(R.id.logoutButtonLayout);

        backIconDoctor.setOnClickListener(v -> finish());

        viewProfileButtonLayout.setOnClickListener(v -> {
            // এখানে তোমার View Profile এর Intent দিবে
            Intent intent = new Intent(DoctorWelcomeActivity.this, DoctorProfileActivity.class);
            startActivity(intent);
        });

        goHomeButtonLayout.setOnClickListener(v -> {
            Intent intent = new Intent(DoctorWelcomeActivity.this, activity_home_page.class);
            startActivity(intent);
            finish();
        });

        logoutButtonLayout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(DoctorWelcomeActivity.this,activity_sign_in.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
