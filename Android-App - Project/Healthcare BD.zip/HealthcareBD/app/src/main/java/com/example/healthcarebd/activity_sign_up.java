package com.example.healthcarebd;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class activity_sign_up extends AppCompatActivity {

    private EditText nameInput, emailInputSignUp, passwordInputSignUp, reEnterPassword;
    private LinearLayout continueSignUpButton, appleSignUpButton;
    private ImageView showPasswordIcon, hidePasswordIcon;

    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        nameInput = findViewById(R.id.rl19kz5chyeg);
        emailInputSignUp = findViewById(R.id.rv5jstmqtjv);
        passwordInputSignUp = findViewById(R.id.r37aptll8zvc);
        reEnterPassword = findViewById(R.id.rempermxpqqq);

        continueSignUpButton = findViewById(R.id.rw205grz43fn);
        appleSignUpButton = findViewById(R.id.rwijan4cxm6);

        showPasswordIcon = findViewById(R.id.showPasswordIcon);
        hidePasswordIcon = findViewById(R.id.hidePasswordIcon);

        ImageView backIcon = findViewById(R.id.rbk1yg4g9wp);

        // Firebase Realtime Database Reference
        userRef = FirebaseDatabase.getInstance().getReference("Users");

        backIcon.setOnClickListener(v -> {
            startActivity(new Intent(activity_sign_up.this, activity_sign_in.class));
            finish();
        });

        passwordInputSignUp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        reEnterPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        reEnterPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        setupSignUpPasswordToggle(passwordInputSignUp);

        continueSignUpButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInputSignUp.getText().toString().trim();
            String password = passwordInputSignUp.getText().toString().trim();
            String rePassword = reEnterPassword.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || rePassword.isEmpty()) {
                Toast.makeText(activity_sign_up.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(activity_sign_up.this, "Enter a valid email", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(rePassword)) {
                Toast.makeText(activity_sign_up.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            checkEmailAndRegister(name, email, password);
        });

        appleSignUpButton.setOnClickListener(v -> {
            String url = "https://appleid.apple.com/account";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });
    }

    private void checkEmailAndRegister(String name, String email, String password) {
        userRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Toast.makeText(activity_sign_up.this, "Email already registered", Toast.LENGTH_SHORT).show();
                } else {
                    registerUser(name, email, password);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(activity_sign_up.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void registerUser(String name, String email, String password) {
        User user = new User(name, email, password, "Patient", "");

        userRef.push().setValue(user)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(activity_sign_up.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(activity_sign_up.this, activity_user_selection.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(activity_sign_up.this, "Failed to sign up", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(activity_sign_up.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    private void setupSignUpPasswordToggle(EditText passwordField) {
        hidePasswordIcon.setVisibility(View.GONE);
        showPasswordIcon.setVisibility(View.VISIBLE);

        hidePasswordIcon.setOnClickListener(v -> {
            passwordField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            passwordField.setSelection(passwordField.getText().length());
            hidePasswordIcon.setVisibility(View.GONE);
            showPasswordIcon.setVisibility(View.VISIBLE);
        });

        showPasswordIcon.setOnClickListener(v -> {
            passwordField.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            passwordField.setSelection(passwordField.getText().length());
            showPasswordIcon.setVisibility(View.GONE);
            hidePasswordIcon.setVisibility(View.VISIBLE);
        });
    }
}
