package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class OnboardingActivity extends AppCompatActivity {

    private int currentStep = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Step Load করো: আগে intent থেকে, না থাকলে SharedPreferences থেকে
        int stepFromIntent = getIntent().getIntExtra("step", -1);
        if (stepFromIntent == -1) {
            currentStep = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                    .getInt("onboardingStep", 1);
        } else {
            currentStep = stepFromIntent;
        }

        showCurrentStep();
    }

    // Step Save করার ফাংশন
    private void saveCurrentStep(int step) {
        getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .edit()
                .putInt("onboardingStep", step)
                .apply();
    }

    // Onboarding Step UI Load + Save
    private void showCurrentStep() {
        saveCurrentStep(currentStep); // step save করো

        switch (currentStep) {
            case 1:
                setContentView(R.layout.activity_onboarding_1);
                findViewById(R.id.r6ms7rhoqquc).setOnClickListener(v -> {
                    currentStep = 2;
                    showCurrentStep();
                });
                break;

            case 2:
                setContentView(R.layout.activity_onboarding_2);
                findViewById(R.id.rx6x724czaq8).setOnClickListener(v -> {
                    currentStep = 3;
                    showCurrentStep();
                });
                findViewById(R.id.rgnqleop83mp).setOnClickListener(v -> {
                    currentStep = 1;
                    showCurrentStep();
                });
                break;

            case 3:
                setContentView(R.layout.activity_onboarding_3);
                findViewById(R.id.rljbl3w2hio).setOnClickListener(v -> {
                    // Onboarding শেষ হলে Step remove করে দাও
                    getSharedPreferences("AppPrefs", MODE_PRIVATE)
                            .edit()
                            .remove("onboardingStep")
                            .apply();

                    Intent intent = new Intent(this, activity_user_selection.class);
                    startActivity(intent);
                    finish();
                });
                findViewById(R.id.rp1pqsjp08y).setOnClickListener(v -> {
                    currentStep = 2;
                    showCurrentStep();
                });
                break;
        }
    }

    // Back press করলে আগের onboarding step এ যাবে
    @Override
    public void onBackPressed() {
        if (currentStep > 1) {
            currentStep--;
            showCurrentStep();
        } else {
            super.onBackPressed();
        }
    }
}
