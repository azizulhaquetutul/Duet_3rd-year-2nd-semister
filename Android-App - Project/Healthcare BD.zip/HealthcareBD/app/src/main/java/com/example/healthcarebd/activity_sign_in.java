package com.example.healthcarebd;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class activity_sign_in extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private TextView continueButton, forgotPasswordText, signUpText;
    private LinearLayout signInWithGoogle, signUpWithApple;
    private ImageView showPasswordIcon, hidePasswordIcon;

    private DatabaseReference databaseReference;
    private String selectedUserType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        selectedUserType = getIntent().getStringExtra("userType");
        if (selectedUserType == null) selectedUserType = "";

        emailInput = findViewById(R.id.rkannsgv43qn);
        passwordInput = findViewById(R.id.r0wgcce6jqv2q);
        continueButton = findViewById(R.id.rituvazkdnk);
        forgotPasswordText = findViewById(R.id.rm9og08yu56h);
        signUpText = findViewById(R.id.rw3axeiljb5b);
        signInWithGoogle = findViewById(R.id.r01cnrkixzsdj);
        signUpWithApple = findViewById(R.id.r5k50c4xy9oh);
        showPasswordIcon = findViewById(R.id.showPasswordIcon);
        hidePasswordIcon = findViewById(R.id.hidePasswordIcon);
        ImageView backIcon = findViewById(R.id.backIcon);

        databaseReference = FirebaseDatabase.getInstance().getReference();

        setupPasswordToggle();
        styleSignUpText();

        backIcon.setOnClickListener(v -> {
            startActivity(new Intent(activity_sign_in.this, activity_user_selection.class));
            finish();
        });

        forgotPasswordText.setOnClickListener(v -> {
            startActivity(new Intent(activity_sign_in.this, ForgotPasswordActivity.class));
            finish();
        });

        signUpText.setOnClickListener(v -> {
            if (selectedUserType.equalsIgnoreCase("Patient")) {
                startActivity(new Intent(activity_sign_in.this, activity_sign_up.class));
                finish();
            } else {
                Toast.makeText(this, "Only Patients can Sign Up", Toast.LENGTH_SHORT).show();
            }
        });

        signInWithGoogle.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.google.com/signin"));
            startActivity(browserIntent);
        });

        signUpWithApple.setOnClickListener(v -> {
            String url = "https://appleid.apple.com/account";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        continueButton.setOnClickListener(v -> {
            if (validateSignInInputs()) {
                String email = emailInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                if (selectedUserType.equalsIgnoreCase("Admin")) {
                    checkAdminLogin(email, password);
                } else if (selectedUserType.equalsIgnoreCase("Doctor")) {
                    checkDoctorLogin(email, password);
                } else if (selectedUserType.equalsIgnoreCase("Patient")) {
                    checkPatientLogin(email, password);
                } else {
                    Toast.makeText(this, "Please select a user type", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void checkAdminLogin(String email, String password) {
        databaseReference.child("Admins").orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot adminSnapshot : snapshot.getChildren()) {
                        String dbPassword = adminSnapshot.child("password").getValue(String.class);
                        if (dbPassword != null && dbPassword.equals(password)) {

                            // ✅ Save userType
                            SharedPreferences sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                            sharedPref.edit().putString("userType", "Admin").apply();

                            Toast.makeText(activity_sign_in.this, "Admin Sign in Successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(activity_sign_in.this, activity_home_page.class));
                            finish();
                            return;
                        }
                    }
                    Toast.makeText(activity_sign_in.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity_sign_in.this, "Admin Not Found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(activity_sign_in.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkDoctorLogin(String email, String password) {
        databaseReference.child("Users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot doctorSnapshot : snapshot.getChildren()) {
                                String userType = doctorSnapshot.child("userType").getValue(String.class);
                                String dbEmail = doctorSnapshot.child("email").getValue(String.class);
                                String dbPassword = doctorSnapshot.child("password").getValue(String.class);

                                if ("Doctor".equalsIgnoreCase(userType)
                                        && dbEmail != null && dbEmail.equalsIgnoreCase(email)
                                        && dbPassword != null && dbPassword.equals(password)) {

                                    // ✅ Save userType
                                    SharedPreferences sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                                    sharedPref.edit().putString("userType", "Doctor").apply();

                                    Toast.makeText(activity_sign_in.this, "Doctor Sign in Successful", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(activity_sign_in.this, activity_home_page.class));
                                    finish();
                                    return;
                                }
                            }
                            Toast.makeText(activity_sign_in.this, "Unauthorized Doctor or Incorrect Password", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(activity_sign_in.this, "Doctor Not Found", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(activity_sign_in.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void checkPatientLogin(String email, String password) {
        databaseReference.child("Users").orderByChild("email").equalTo(email).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String userType = userSnapshot.child("userType").getValue(String.class);
                        if (userType == null || !userType.equalsIgnoreCase("Patient")) continue;

                        String dbPassword = userSnapshot.child("password").getValue(String.class);
                        if (dbPassword != null && dbPassword.equals(password)) {

                            // ✅ Save userType
                            SharedPreferences sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                            sharedPref.edit().putString("userType", "Patient").apply();

                            Toast.makeText(activity_sign_in.this, "Patient Sign in Successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(activity_sign_in.this, activity_home_page.class));
                            finish();
                            return;
                        }
                    }
                    Toast.makeText(activity_sign_in.this, "Incorrect Password or Not a Patient", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity_sign_in.this, "Patient Not Found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(activity_sign_in.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupPasswordToggle() {
        passwordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
        hidePasswordIcon.setVisibility(View.GONE);
        showPasswordIcon.setVisibility(View.VISIBLE);

        hidePasswordIcon.setOnClickListener(v -> {
            passwordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
            passwordInput.setSelection(passwordInput.getText().length());
            hidePasswordIcon.setVisibility(View.GONE);
            showPasswordIcon.setVisibility(View.VISIBLE);
        });

        showPasswordIcon.setOnClickListener(v -> {
            passwordInput.setTransformationMethod(null);
            passwordInput.setSelection(passwordInput.getText().length());
            showPasswordIcon.setVisibility(View.GONE);
            hidePasswordIcon.setVisibility(View.VISIBLE);
        });
    }

    private boolean validateSignInInputs() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        boolean isValid = true;

        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Enter a valid email address");
            isValid = false;
        }

        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            isValid = false;
        }

        if (!isValid) {
            Toast.makeText(activity_sign_in.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        }

        return isValid;
    }

    private void styleSignUpText() {
        String fullText = "Don’t have an account? Sign up";
        String clickablePart = "Sign up";

        SpannableString spannable = new SpannableString(fullText);
        spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#5772F5")),
                fullText.indexOf(clickablePart),
                fullText.indexOf(clickablePart) + clickablePart.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new UnderlineSpan(),
                fullText.indexOf(clickablePart),
                fullText.indexOf(clickablePart) + clickablePart.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        signUpText.setText(spannable);
    }
}
