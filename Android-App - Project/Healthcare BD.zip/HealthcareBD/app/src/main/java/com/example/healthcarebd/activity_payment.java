package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class activity_payment extends AppCompatActivity {

    EditText edtName, edtAmount, edtDescription;
    Spinner spinnerPaymentMethod;
    Button btnMakePayment;
    TextView tvTransactionDetails;

    String[] paymentMethods = {"Bkash", "Nagad", "Rocket"};

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        edtName = findViewById(R.id.idEdtName);
        edtAmount = findViewById(R.id.idEdtAmount);
        edtDescription = findViewById(R.id.idEdtDescription);
        spinnerPaymentMethod = findViewById(R.id.idSpinnerPaymentMethod);
        btnMakePayment = findViewById(R.id.idBtnMakePayment);
        tvTransactionDetails = findViewById(R.id.idTVTransactionDetails);

        // Spinner setup
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, paymentMethods
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPaymentMethod.setAdapter(adapter);

        // Firebase Reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Payments");

        btnMakePayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edtName.getText().toString().trim();
                String amount = edtAmount.getText().toString().trim();
                String method = spinnerPaymentMethod.getSelectedItem().toString();
                String transactionId = edtDescription.getText().toString().trim();

                if (name.isEmpty() || amount.isEmpty() || transactionId.isEmpty()) {
                    Toast.makeText(activity_payment.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    PaymentModel payment = new PaymentModel(name, amount, method, transactionId);

                    // Save to Firebase
                    databaseReference.push().setValue(payment).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            String result = "Payment of ৳" + amount +
                                    " via " + method + "\nName: " + name +
                                    "\nTransaction ID: " + transactionId;

                            tvTransactionDetails.setText(result);
                            tvTransactionDetails.setVisibility(View.VISIBLE);
                            Toast.makeText(activity_payment.this, "Payment saved to Firebase!", Toast.LENGTH_SHORT).show();

                            // Navigate after delay
                            new android.os.Handler().postDelayed(() -> {
                                startActivity(new Intent(activity_payment.this, activity_doctor_appointments.class));
                                finish();
                            }, 1000);
                        } else {
                            Toast.makeText(activity_payment.this, "Failed to save to Firebase", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
