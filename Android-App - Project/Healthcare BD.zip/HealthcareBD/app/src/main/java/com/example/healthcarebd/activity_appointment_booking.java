package com.example.healthcarebd;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;

public class activity_appointment_booking extends AppCompatActivity {

    ImageView icbackarrow1, icSearch1, icMic1, fabAddDoctor1;
    EditText searchInput1;
    LinearLayout navHome, navConsults, navScan, navBookings, navProfile;

    RecyclerView doctorRecyclerView;
    ArrayList<User> doctorList, filteredList;
    DoctorAdapter doctorAdapter;

    DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_booking);

        // Firebase reference
        userRef = FirebaseDatabase.getInstance().getReference("Users");

        // Initialize views
        icbackarrow1 = findViewById(R.id.icbackarrow1);
        icSearch1 = findViewById(R.id.icSearch1);
        icMic1 = findViewById(R.id.icMic1);
        searchInput1 = findViewById(R.id.searchInput1);
        fabAddDoctor1 = findViewById(R.id.fabAddDoctor1);

        navHome = findViewById(R.id.rzfditkz8wsj);
        navConsults = findViewById(R.id.r2m1b5oo1qfo);
        navScan = findViewById(R.id.rrxiwn0hmwp);
        navBookings = findViewById(R.id.rtsebyjnvndh);
        navProfile = findViewById(R.id.r8panjt8bize);

        // RecyclerView setup
        doctorRecyclerView = findViewById(R.id.recyclerDoctorList);
        doctorRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        doctorList = new ArrayList<>();
        filteredList = new ArrayList<>();
        doctorAdapter = new DoctorAdapter(this, filteredList);
        doctorRecyclerView.setAdapter(doctorAdapter);

        // Load doctor list from Firebase
        loadDoctors();

        // Back button
        icbackarrow1.setOnClickListener(v -> finish());

        // Search icon click
        icSearch1.setOnClickListener(v -> performSearch(searchInput1.getText().toString().trim()));

        // Voice input click
        icMic1.setOnClickListener(v -> {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            try {
                startActivityForResult(intent, 100);
            } catch (Exception e) {
                Toast.makeText(this, "Voice not supported", Toast.LENGTH_SHORT).show();
            }
        });

        // ✅ Only Admin can access Add Doctor
        fabAddDoctor1.setOnClickListener(v -> {
            SharedPreferences sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String userType = sharedPref.getString("userType", "");

            if ("Admin".equalsIgnoreCase(userType)) {
                startActivity(new Intent(this, activity_admin_add_doctor.class));
            } else {
                Toast.makeText(this, "Only admins can access this feature.", Toast.LENGTH_SHORT).show();
            }
        });

        // Bottom Navigation
        navHome.setOnClickListener(v -> startActivity(new Intent(this, activity_home_page.class)));
        navConsults.setOnClickListener(v -> Toast.makeText(this, "Consults Clicked", Toast.LENGTH_SHORT).show());
        navScan.setOnClickListener(v -> Toast.makeText(this, "Scan Clicked", Toast.LENGTH_SHORT).show());
        navBookings.setOnClickListener(v -> Toast.makeText(this, "Bookings Clicked", Toast.LENGTH_SHORT).show());
        navProfile.setOnClickListener(v -> {
            Intent intent = new Intent(this,DoctorProfileActivity.class);
            startActivity(intent);
        });
    }

    // 🔄 Load only Doctors
    private void loadDoctors() {
        userRef.orderByChild("userType").equalTo("Doctor")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        doctorList.clear();
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            User doctor = snap.getValue(User.class);
                            if (doctor != null) {
                                doctorList.add(doctor);
                            }
                        }
                        filteredList.clear();
                        filteredList.addAll(doctorList);
                        doctorAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(activity_appointment_booking.this, "Failed to load doctors", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // 🔍 Search logic
    private void performSearch(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(doctorList);
        } else {
            for (User doctor : doctorList) {
                if (doctor.name.toLowerCase().contains(query.toLowerCase()) ||
                        doctor.specialist.toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(doctor);
                }
            }
        }
        doctorAdapter.notifyDataSetChanged();
    }

    // 🎤 Voice input
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                String voiceText = result.get(0);
                searchInput1.setText(voiceText);
                performSearch(voiceText);
            }
        }
    }
}
