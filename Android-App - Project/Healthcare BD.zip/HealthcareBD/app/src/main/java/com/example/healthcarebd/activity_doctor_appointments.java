package com.example.healthcarebd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class activity_doctor_appointments extends AppCompatActivity {

    LinearLayout navHome, navConsults, navScan, navBookings, navProfile;
    LinearLayout upcomingTab, completedTab, cancelledTab;
    TextView upcomingText, completedText, cancelledText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_appointments); // Your layout XML file

        // Back button
        ImageView backButton = findViewById(R.id.rb34v12qlqli);
        backButton.setOnClickListener(v -> finish());

        // Tabs for Upcoming / Completed / Cancelled
        upcomingTab = findViewById(R.id.rssib4am9fi);
        completedTab = findViewById(R.id.rqtv46yhlqo);
        cancelledTab = findViewById(R.id.rd8da6hjmudq);

        upcomingText = findViewById(R.id.rqlrg7i12w7);
        completedText = findViewById(R.id.rnzswz7hp9l8);
        cancelledText = findViewById(R.id.rlathrc79m2f);

        setupTabClicks();

        // Bottom navigation setup
        navHome = findViewById(R.id.navHome);
        navConsults = findViewById(R.id.navConsults);
        navScan = findViewById(R.id.navScan);
        navBookings = findViewById(R.id.navBookings);
        navProfile = findViewById(R.id.navProfile);

        navHome.setOnClickListener(v -> startActivity(new Intent(this, activity_home_page.class)));
        navConsults.setOnClickListener(v -> startActivity(new Intent(this,activity_patient_profile.class)));
        navScan.setOnClickListener(v -> startActivity(new Intent(this, activity_home_page.class))); // You can change this if scan has a separate activity
        navBookings.setOnClickListener(v -> recreate()); // Current screen, just refresh
        navProfile.setOnClickListener(v -> startActivity(new Intent(this, activity_patient_welcome_doctor.class)));
    }

    private void setupTabClicks() {
        // Default tab
        highlightTab(upcomingTab, upcomingText);
        unhighlightTab(completedTab, completedText);
        unhighlightTab(cancelledTab, cancelledText);

        // Click listeners
        upcomingTab.setOnClickListener(v -> {
            highlightTab(upcomingTab, upcomingText);
            unhighlightTab(completedTab, completedText);
            unhighlightTab(cancelledTab, cancelledText);
            // TODO: Load or display upcoming appointments here
        });

        completedTab.setOnClickListener(v -> {
            highlightTab(completedTab, completedText);
            unhighlightTab(upcomingTab, upcomingText);
            unhighlightTab(cancelledTab, cancelledText);
            // TODO: Load or display completed appointments here
        });

        cancelledTab.setOnClickListener(v -> {
            highlightTab(cancelledTab, cancelledText);
            unhighlightTab(upcomingTab, upcomingText);
            unhighlightTab(completedTab, completedText);
            // TODO: Load or display cancelled appointments here
        });
    }

    private void highlightTab(LinearLayout layout, TextView label) {
        layout.setBackgroundResource(R.drawable.cr8b3333de); // Red background with rounded corners
        label.setTextColor(getResources().getColor(android.R.color.white));
    }

    private void unhighlightTab(LinearLayout layout, TextView label) {
        layout.setBackgroundResource(R.drawable.s28272csw1cr8bffffff); // Light background
        label.setTextColor(getResources().getColor(R.color.black)); // or use custom color #28272C
    }
}
