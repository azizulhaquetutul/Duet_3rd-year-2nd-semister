package com.example.healthcarebd;

public class PaymentModel {
    public String name;
    public String amount;
    public String method;
    public String transactionId;

    public PaymentModel() {
        // Default constructor required for Firebase
    }

    public PaymentModel(String name, String amount, String method, String transactionId) {
        this.name = name;
        this.amount = amount;
        this.method = method;
        this.transactionId = transactionId;
    }
}
